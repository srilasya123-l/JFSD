package com.STK.Hibernate_CRUD;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
      try {
        System.out.println( "Hello Hibernate" );
        
        Configuration cfg=new Configuration();
        cfg.configure();
        SessionFactory sf= cfg.buildSessionFactory();
        Session s = sf.openSession();
        Transaction tnx = s.beginTransaction();
        
        Student sd=new Student();
        sd.setSid(2);
        sd.setSname("lohitha");
        sd.setEmailid("ammuluchinnu0813@gmail.com");
        sd.setFee(150000);
        
        sd.setSid(3);
        sd.setSname("ammulu");
        sd.setEmailid("lohithasubbu0829@gmail.com");
        sd.setFee(15000);
        
        
        Student sd2 = s.find(Student.class, 1);
        sd.setSname("Lasya");
        s.merge(sd2);
        System.out.println("Data updated");      
         
         
        
        s.save(sd);
        System.out.println( "Data Inserted" );
        tnx.commit();
        s.close();
        
      }catch(Exception e) {
        e.printStackTrace();
      }
    }
}